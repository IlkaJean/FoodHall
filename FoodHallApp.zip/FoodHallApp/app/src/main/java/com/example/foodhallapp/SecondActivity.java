package com.example.foodhallapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class SecondActivity extends AppCompatActivity {

    TextView food1Text;
    TextView food2Text;
    TextView food3Text;
    TextView food4Text;
    Button food1BT;
    Button food2BT;
    Button food3BT;
    Button food4BT;
    boolean voted = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        food1Text = findViewById(R.id.food1_count);
        food2Text = findViewById(R.id.food2_count);
        food3Text = findViewById(R.id.food3_count);
        food4Text = findViewById(R.id.food3_count);

        food1BT = findViewById(R.id.food1_bt);
        food2BT = findViewById(R.id.food2_bt);
        food3BT = findViewById(R.id.food3_bt);
        food4BT = findViewById(R.id.food3_bt);
    }

    public void onClick(View v) {
        Intent in = new Intent(SecondActivity.this, ThirdActivity.class);
        startActivity(in);
    }

    public void onClickFood1 (View v){
        String food1Count = food1Text.getText().toString().trim();
        int count = Integer.parseInt(food1Count);
        if (!voted){
            count++;
            voted = true;
        }
        food1Text.setText(String.valueOf(count));
    }

    public void onClickFood2 (View v){
        String food2Count = food2Text.getText().toString().trim();
        int count = Integer.parseInt(food2Count);
        if (!voted){
            count++;
            voted = true;
        }
        food2Text.setText(String.valueOf(count));
    }

    public void onClickFood3 (View v){
        String food3Count = food3Text.getText().toString().trim();
        int count = Integer.parseInt(food3Count);
        if (!voted){
            count++;
            voted = true;
        }
        food3Text.setText(String.valueOf(count));
    }

    public void onClickFood4 (View v){
        String food4Count = food4Text.getText().toString().trim();
        int count = Integer.parseInt(food4Count);
        if (!voted){
            count++;
            voted = true;
        }
        food3Text.setText(String.valueOf(count));
    }
}