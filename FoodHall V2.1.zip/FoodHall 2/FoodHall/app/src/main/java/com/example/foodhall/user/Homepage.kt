package com.example.foodhall.user


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.example.foodhall.R
import kotlinx.android.synthetic.main.activity_homepage.*
//import kotlinx.android.synthetic.main.activity_main.*

class Homepage : AppCompatActivity() {

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_homepage)

            val firstFragment= FirstFragment()
            val secondFragment= SecondFragment()
            val thirdFragment= ThirdFragment()
            val fourthFragment= FourthFragment()

            setCurrentFragment(firstFragment)

            bottomNavigationView.setOnNavigationItemSelectedListener {
                when(it.itemId){
                    R.id.home ->setCurrentFragment(firstFragment)
                    R.id.map ->setCurrentFragment(secondFragment)
                    R.id.events ->setCurrentFragment(thirdFragment)
                    R.id.settings ->setCurrentFragment(fourthFragment)

                }
                true
            }

        }

        private fun setCurrentFragment(fragment: Fragment)=
                supportFragmentManager.beginTransaction().apply {
                    replace(R.id.flFragment,fragment)
                    commit()
                }


}