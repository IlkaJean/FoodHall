package com.example.foodhall.user

import androidx.fragment.app.Fragment
import com.example.foodhall.R

class FourthFragment: Fragment(R.layout.activity_fragment_fourth) {


}