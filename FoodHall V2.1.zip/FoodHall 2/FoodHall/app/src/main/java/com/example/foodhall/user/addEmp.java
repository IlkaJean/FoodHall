package com.example.foodhall.user;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.foodhall.R;

public class addEmp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_emp);
    }
}