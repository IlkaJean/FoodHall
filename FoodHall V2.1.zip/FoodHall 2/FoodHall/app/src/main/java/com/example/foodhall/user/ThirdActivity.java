package com.example.foodhall.user;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.foodhall.R;
import com.example.foodhall.db.dbHelperMain;

public class ThirdActivity extends AppCompatActivity {

    dbHelperMain db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        db = new dbHelperMain(this);
        Cursor res = db.getUserData();
        TextView tx1 = (TextView) findViewById(R.id.tx1);
        TextView tx2 = (TextView) findViewById(R.id.tx2);
        TextView tx3 = (TextView) findViewById(R.id.tx3);
        Bundle extras = getIntent().getExtras();
        if(extras!=null){
            String un = (String) extras.getString("USER");
            tx1.setText(un);
            while (res.moveToNext()) {
                if (res.getString(0) .equals(un)) {
                    tx1.setText(res.getString(0));
                    tx2.setText(res.getString(1));
                    tx3.setText(res.getString(2));
                }
            }
        }

        /*
        while (res.moveToNext()) {
            if (res.getString(0) == un) {
                //tx1.setText(res.getString(0));
                //tx2.setText(res.getString(1));
                //tx3.setText(res.getString(2));
            }
          }

         */
     }

    public void Getdata(View v) {
        Cursor res = db.getUserData();
        TextView tx1 = (TextView) findViewById(R.id.tx1);
        TextView tx2 = (TextView) findViewById(R.id.tx2);
        TextView tx3 = (TextView) findViewById(R.id.tx3);
        Bundle extras = getIntent().getExtras();
        String un = extras.getString("un");

        while (res.moveToNext()) {
            if (res.getString(0) == un) {
                tx1.setText(res.getString(0));
                tx2.setText(res.getString(1));
                tx3.setText(res.getString(2));
            }
        }
    }
        public void onClick (View v){
            Intent in = new Intent(com.example.foodhall.user.ThirdActivity.this, addEmp.class);
            startActivity(in);
        }
    }