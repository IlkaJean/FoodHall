package com.example.foodhall.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import com.example.foodhall.db.itemHelper.*;

import androidx.annotation.Nullable;

public class dbHelperMain extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "foodhall.db";
    public static int orderNumber;
    Context ct;

    // Table Names
    private static final String TABLE_USER = "user";
    private static final String TABLE_VENDOR = "vendor";
    private static final String TABLE_Orders = "orders";
    private static final String TABLE_RestInfo = "restinfo";

    //Restaurant Strings
    private static final String TABLERESTNAME = "restaurantinfo";
    private static final String COL_RNAME = "resname";
    private static final String COL_RDESC = "resdesc";
    private static final String COL_ID = "id";


    public dbHelperMain(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        ct= context;
        SQLiteDatabase db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //Order Table
        final String SQL_CREATE_ORDER_TABLE = "CREATE TABLE " +
                OrderEntry.Table_Name_ORD + " (" +
                OrderEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                OrderEntry.COLUMN_ITEM_NUM + " INTEGER, " +
                OrderEntry.COLUMN_ORDER_NUM + " INTEGER, " +
                OrderEntry.COLUMN_DESC + " TEXT, " +
                OrderEntry.COLUMN_PRICE + " INTEGER, " +
                OrderEntry.COLUMN_INSTR + " TEXT, " +
                OrderEntry.COLUMN_DATETIME + " TIMESTAMP DEFAULT CURRENT_TIMESTAMP " +
                ");";
        //Create Order Table
        db.execSQL(SQL_CREATE_ORDER_TABLE);
        //Create User Table
        db.execSQL("Create table user(username text primary key, password text, account_type INTEGER, access_right INTEGER, rest_name text)");
        //MENU TABLE

        final String SQL_CREATE_MENU_TABLE = "CREATE TABLE " +
                OrderEntry.Table_Name_Menu + " (" +
                OrderEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                OrderEntry.COLUMN_NAME + " INTEGER, " +
                OrderEntry.COLUMN_DESC + " TEXT, " +
                OrderEntry.COLUMN_PRICE + " TEXT, " +
                OrderEntry.COLUMN_IMG + " INTEGER, " +
                OrderEntry.COLUMN_AM + " INTEGER " +
                ");";
        db.execSQL(SQL_CREATE_MENU_TABLE);

        //RESTAURANT TABLE
        final String SQL_CREATE_REST_TABLE = "CREATE TABLE " + TABLERESTNAME + " (" + COL_ID
                + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COL_RNAME + " TEXT, " + COL_RDESC + " TEXT ) ";
        db.execSQL(SQL_CREATE_REST_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + OrderEntry.Table_Name_ORD);
        db.execSQL("drop table if exists user");
        db.execSQL("DROP TABLE IF EXISTS " + OrderEntry.Table_Name_Menu);
        db.execSQL("DROP TABLE IF EXISTS restaurantinfo");
        onCreate(db);
    }

    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + OrderEntry.Table_Name_ORD);
        db.execSQL("drop table if exists user");
        db.execSQL("DROP TABLE IF EXISTS " + OrderEntry.Table_Name_Menu);
        db.execSQL("DROP TABLE IF EXISTS restaurantinfo");
        onCreate(db);
    }

    //CODE FOR ORDER INFORMATION
    public boolean insertData(int itemNum, int orderNum, String desc, int price, String instr) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(OrderEntry.COLUMN_ITEM_NUM, itemNum);
        contentValues.put(OrderEntry.COLUMN_ORDER_NUM, orderNum);
        contentValues.put(OrderEntry.COLUMN_DESC, desc);
        contentValues.put(OrderEntry.COLUMN_PRICE, price);
        contentValues.put(OrderEntry.COLUMN_INSTR, instr);
        long result = db.insert(OrderEntry.Table_Name_ORD, null, contentValues);
        if (result == -1)
            return false;
        else
            return true;
    }

    public Cursor getAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("SELECT * FROM " + OrderEntry.Table_Name_ORD, null);
        return res;
    }

    public int getLastOrder() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("SELECT * FROM " + OrderEntry.Table_Name_ORD, null);
        res.moveToLast();
        int lastOrderNum = res.getInt(2);
        orderNumber = lastOrderNum;
        return lastOrderNum;

    }
    public void deleteOrder(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(OrderEntry.Table_Name_ORD,OrderEntry._ID+"="+id,null);
    }

    public int getOrderPrice(){
        SQLiteDatabase db = this.getWritableDatabase();
        int currOrder = getLastOrder()+1;
        Cursor res = getAllData();
        int currOrderPrice=0;
        while (res.moveToNext()){
            if (res.getInt(3)==currOrder){
                currOrderPrice = currOrderPrice+res.getInt(5);
            }
        }
        return currOrderPrice;
    }


    //CODE FOR USER DATA
    public boolean insertUser(String username, String password, int account_type, int access_right, String rest_name) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        contentValues.put("account_type", account_type);
        contentValues.put("access_right", access_right);
        contentValues.put("rest_name", rest_name);
        long ins = db.insert("user",null,contentValues);
        if(ins == -1) return false;
        else return true;
    }
    public Boolean ckuser(String username){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from user where username=?", new String[]{username});
        if(cursor.getCount() > 0) return false;
        else return true;
    }
    public Boolean usernamepassword(String username, String password){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from user where username=? and password=?", new String[]{username,password});
        if(cursor.getCount()>0) return true;
        else return false;
    }

    public Cursor getUserData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("SELECT * FROM user",null);
        return res;
    }

    //CODE FOR MENU
    public boolean modifyData(int am){
        SQLiteDatabase db = this.getWritableDatabase();
        am++;
        ContentValues contentValues = new ContentValues();
        contentValues.put(OrderEntry.COLUMN_AM, am);
        long result = db.insert(OrderEntry.Table_Name_Menu, null, contentValues);
        if(result ==-1)
            return false;
        else
            return true;
    }

    public boolean insertMenuData(String Name, String Desc, String Price, int img, int am){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(OrderEntry.COLUMN_NAME, Name);
        contentValues.put(OrderEntry.COLUMN_DESC, Desc);
        contentValues.put(OrderEntry.COLUMN_PRICE, Price);
        contentValues.put(OrderEntry.COLUMN_IMG, img);
        contentValues.put(OrderEntry.COLUMN_AM, am);
        long result = db.insert(OrderEntry.Table_Name_Menu, null, contentValues);
        if(result ==-1)
            return false;
        else
            return true;
    }
    public Cursor getMenuData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("SELECT * FROM "+OrderEntry.Table_Name_Menu,null);
        return res;
    }

    //CODE FOR RESTAURANT INFORMATION

    public boolean insertRestData(String rname, String rdes) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_RNAME, rname);
        contentValues.put(COL_RDESC, rdes);
        long result = db.insert(TABLERESTNAME, null, contentValues);
        if(result ==-1){
            Toast.makeText(ct, "Failed", Toast.LENGTH_SHORT).show();
            return false;}
        else
            {
            Toast.makeText(ct, "Success", Toast.LENGTH_SHORT).show();
            return true;
        }
    }

}
