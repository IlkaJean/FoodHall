package com.example.foodhall.db;

import android.provider.BaseColumns;

public class itemHelper {

    public static final class OrderEntry implements BaseColumns {
        public static final String Table_Name_ORD = "orderList";
        public static final String Table_Name_Menu = "menuList";
        public static final String COLUMN_ITEM_NUM = "MenuNum";
        public static final String COLUMN_ORDER_NUM = "OrderNum";
        public static final String COLUMN_PRICE = "Price";
        public static final String COLUMN_DESC = "Description";
        public static final String COLUMN_INSTR = "Instructions";
        public static final String COLUMN_DATETIME = "OrderTime";
        public static final String COLUMN_AM = "Amount";
        public static final String COLUMN_IMG = "ImgFile";
        public static final String COLUMN_NAME= "MenuName";

    }
}
