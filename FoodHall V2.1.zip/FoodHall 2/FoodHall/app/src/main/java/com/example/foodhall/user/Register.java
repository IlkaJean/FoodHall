package com.example.foodhall.user;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.foodhall.R;
import com.example.foodhall.db.dbHelperMain;

public class Register extends AppCompatActivity {
    dbHelperMain db;
    EditText e1, e2, e3, e4, e5;
    Button b1;
    RadioGroup radioGroup;
    RadioButton radioButton, radioButton2;
    Integer account_type = 1;
    Integer access_right = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        radioGroup = findViewById(R.id.radioGroup);
        radioButton = findViewById(R.id.radioButton);
        radioButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                e4.setVisibility(View.GONE);
                e5.setVisibility(View.GONE);
                account_type = 1;
                access_right = 0;
            }
        });
        radioButton2 = findViewById(R.id.radioButton2);
        radioButton2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                e4.setVisibility(View.VISIBLE);
                e5.setVisibility(View.VISIBLE);
                account_type = 2;
                access_right = 1;
            }
        });

        db = new dbHelperMain(this);
        e1 = (EditText)findViewById(R.id.username);
        e2 = (EditText)findViewById(R.id.pass);
        e3 = (EditText)findViewById(R.id.cpass);
        e4 = (EditText)findViewById(R.id.rest_name);
        e5 = (EditText)findViewById(R.id.rest_id);
        b1 = (Button)findViewById(R.id.bt_register);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1 = e1.getText().toString();
                String s2 = e2.getText().toString();
                String s3 = e3.getText().toString();
                String s4 = e4.getText().toString();

                radioButton.setOnClickListener(new View.OnClickListener(){
                    public void onClick(View v){
                        e4.setVisibility(View.GONE);
                        e5.setVisibility(View.GONE);
                        e4.getText().clear();
                        e5.getText().clear();
                        account_type = 1;
                        access_right = 0;
                    }
                });

                radioButton2.setOnClickListener(new View.OnClickListener(){
                    public void onClick(View v){
                        e4.setVisibility(View.VISIBLE);
                        e5.setVisibility(View.VISIBLE);
                        e4.getText().clear();
                        e5.getText().clear();
                        account_type = 2;
                        access_right = 1;
                    }
                });

                if(s1.equals("")||s2.equals("")||s3.equals("")){
                    Toast.makeText(getApplicationContext(),"Fields are empty",Toast.LENGTH_SHORT).show();
                }
                else{
                    if(s2.equals(s3)){
                        Boolean ckuser = db.ckuser(s1);
                        if(ckuser==true){
                            Boolean insert = db.insertUser(s1,s2,account_type,access_right,s4);
                            if(insert==true){
                                Toast.makeText(getApplicationContext(),"Registered Successfully", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else{
                            Toast.makeText(getApplicationContext(),"Username already exists",Toast.LENGTH_SHORT).show();
                        }
                    }
                    Toast.makeText(getApplicationContext(),"Password do not match",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}