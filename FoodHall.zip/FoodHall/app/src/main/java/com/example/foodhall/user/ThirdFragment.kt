package com.example.foodhall.user

import androidx.fragment.app.Fragment
import com.example.foodhall.R

class ThirdFragment:Fragment(R.layout.activity_fragment_third) {
}