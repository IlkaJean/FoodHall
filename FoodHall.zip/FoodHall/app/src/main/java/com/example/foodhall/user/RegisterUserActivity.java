package com.example.foodhall.user;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.foodhall.R;

public class RegisterUserActivity extends AppCompatActivity {
    UserDatabaseHelper db;
    EditText e1, e2, e3;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);

        db = new UserDatabaseHelper(this);
        e1 = (EditText)findViewById(R.id.editTextUserName);
        e2 = (EditText)findViewById(R.id.editTextTextPassword);
        e3 = (EditText)findViewById(R.id.editTextTextPassword2);
        b1 = (Button)findViewById(R.id.buttonRegister);
        b1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                String s1 = e1.getText().toString();
                String s2 = e2.getText().toString();
                String s3 = e3.getText().toString();
                if(s1.equals("")||s2.equals("")||s3.equals("")){
                    Toast.makeText(getApplicationContext(),"Fields are empty",Toast.LENGTH_SHORT).show();
                }
                else{
                    if(s2.equals(s3)){
                        Boolean ckuser = db.ckuser(s1);
                        if(ckuser==true){
                            Boolean insert = db.insert(s1,s2);
                            if(insert==true){
                                Toast.makeText(getApplicationContext(),"Registered Successfully", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else{
                            Toast.makeText(getApplicationContext(),"Username already exists",Toast.LENGTH_SHORT).show();
                        }
                    }
                    Toast.makeText(getApplicationContext(),"Password do not match",Toast.LENGTH_SHORT).show();
                }
            }

        });


    }
    public void gotoLoginUserActivity(View v){
        Intent intent = new Intent(this, LoginUserActivity.class);
        startActivity(intent);
    }
}