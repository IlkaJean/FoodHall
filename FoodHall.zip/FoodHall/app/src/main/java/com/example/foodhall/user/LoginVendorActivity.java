package com.example.foodhall.user;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.foodhall.R;

public class LoginVendorActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_vendor);
    }
}