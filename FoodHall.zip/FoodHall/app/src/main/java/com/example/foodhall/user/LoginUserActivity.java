package com.example.foodhall.user;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.foodhall.R;

public class LoginUserActivity extends AppCompatActivity {
    UserDatabaseHelper db;
    EditText ed1, ed2;
    TextView txt1;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_user);

        db = new UserDatabaseHelper(this);

        ed1 = (EditText)findViewById(R.id.editTextUserName);
        ed2 = (EditText)findViewById(R.id.editTextPassword);

        b1 = (Button)findViewById(R.id.buttonLogin);
        txt1 = (TextView)findViewById(R.id.textViewRegister);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(LoginUserActivity.this, Homepage.class);
                String username = ed1.getText().toString();
                String password = ed2.getText().toString();
                Boolean ckusernamepassword = db.usernamepassword(username, password);
                if (ckusernamepassword == true) {
                    startActivity(in);
                    Toast.makeText(getApplicationContext(), "Welcome! " + username, Toast.LENGTH_SHORT).show();
                }
                else
                    Toast.makeText(getApplicationContext(), "Wrong username or password", Toast.LENGTH_SHORT).show();
            }
        });

        txt1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Intent in=new Intent(LoginUserActivity.this,RegisterUserActivity.class);
                startActivity(in);
            }
        });
    }
//    public void gotoHomePage(View v){
//        Intent intent = new Intent(this, Homepage.class);
//        startActivity(intent);
//    }

//    public void gotoRegisterUser(View v){
//        Intent intent = new Intent(this, RegisterUserActivity.class);
//        startActivity(intent);
//    }
}